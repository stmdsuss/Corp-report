@echo off
cd /d "%~dp0"
docker compose stop
echo Services stopped. Test data is preserved.
pause
