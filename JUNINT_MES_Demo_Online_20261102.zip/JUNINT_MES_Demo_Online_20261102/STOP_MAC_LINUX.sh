#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
docker compose stop
echo 'Services stopped. Test data is preserved.'
