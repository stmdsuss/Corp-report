"""Observation commands. No inventory, physical LOT, quality or shipment effects."""
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from zoneinfo import ZoneInfo

from sqlalchemy import select

from .database import Activation, Audit, Model, Policy, Prepared, Run, Snapshot, Source, TimeRecord, now, uid


class Rejected(Exception):
    def __init__(self, code, message, status=422):
        self.code, self.message, self.status = code, message, status


def require(condition, code, message, status=422):
    if not condition:
        raise Rejected(code, message, status)


def get(db, cls, id):
    require(isinstance(id,str) and 0 < len(id) <= 160,'INVALID_ID','대상 ID를 확인하세요.')
    row = db.get(cls, id)
    require(row is not None, 'NOT_FOUND', '대상 기록이 없습니다.', 404)
    return row


def qty(value, optional=False):
    if value is None and optional:
        return None
    require(isinstance(value, str) and bool(value.strip()), 'QUANTITY_REQUIRED', '수량은 빈칸이 아닌 Decimal 문자열이어야 합니다.')
    try:
        n = Decimal(value)
    except InvalidOperation:
        raise Rejected('INVALID_QUANTITY', '수량 형식을 확인하세요.')
    require(n.is_finite() and 0 <= n < Decimal('1000000000000000000') and n.as_tuple().exponent >= -6,
            'INVALID_QUANTITY', '수량은 0 이상, 소수 6자리 이하로 입력하세요.')
    return n


def dec(n):
    if n is None:
        return None
    return format(n.normalize(), 'f')


def timestamp(value):
    if value is None:
        return None
    try:
        d = datetime.fromisoformat(value.replace('Z', '+00:00'))
    except (ValueError, AttributeError):
        raise Rejected('INVALID_TIME', '시각은 시간대가 있는 ISO 형식이어야 합니다.')
    require(d.tzinfo is not None, 'TIMEZONE_REQUIRED', '시간대가 필요합니다.')
    return d.astimezone(timezone.utc)


def audit(db, actor, action, entity_id, before, after, reason=None):
    db.add(Audit(actor_id=actor, action=action, entity_id=entity_id, before=before, after=after, reason=reason))


def latest(db, run):
    return db.scalar(select(Snapshot).where(Snapshot.run_id == run.id).order_by(Snapshot.version.desc()))


def policy(db, station_id):
    return db.scalar(select(Policy).where(Policy.station_id == station_id).order_by(Policy.version.desc()))


def current(db, station_id):
    return db.scalar(select(Run).where(Run.station_id == station_id, Run.state == 'ACTIVE'))


def check_version(row, data):
    require(type(data.get('expected_version')) is int and row.row_version == data['expected_version'],
            'VERSION_CONFLICT', '다른 단말에서 기록이 변경되었습니다. 원본은 검토함에 보존됩니다.', 409)


def run_dict(db, r):
    s, p = latest(db, r), db.get(Policy, r.policy_id) if r.policy_id else None
    times = db.scalars(select(TimeRecord).where(TimeRecord.run_id == r.id).order_by(TimeRecord.recorded_at)).all()
    return dict(id=r.id, station_id=r.station_id, model_id=r.model_id, model=r.model_snapshot,
                state=r.state, row_version=r.row_version, run_kind=r.run_kind,
                coverage_mode=r.coverage_mode, order_ref=r.order_ref,
                order_assignment_state='ASSIGNED' if r.order_ref else 'UNASSIGNED', target_qty=dec(r.target_qty),
                reported_completed_qty=dec(s.quantity) if s else None,
                report_status=s.report_status if s else 'NOT_REPORTED',
                exception_quantities=s.exception_quantities if s else {},
                policy={'id': p.id, 'version': p.version, 'unit': p.unit, 'boundary': p.boundary,
                        'inclusion': p.inclusion, 'state': p.state, 'decimal_places': p.decimal_places} if p else None,
                basis_status='CONFIRMED' if p and p.state == 'CONFIRMED' else 'COUNT_BASIS_UNCONFIRMED',
                started_recorded_at=r.started_recorded_at.isoformat(),
                close_recorded_at=r.close_recorded_at.isoformat() if r.close_recorded_at else None,
                time_records=[dict(event_kind=t.event_kind, occurred_at_claimed=t.occurred_at_claimed.isoformat() if t.occurred_at_claimed else None,
                                   time_basis=t.time_basis, client_entered_at=t.client_entered_at.isoformat() if t.client_entered_at else None,
                                   recorded_at=t.recorded_at.isoformat(), evidence=t.evidence) for t in times],
                quality_release='N/A', shipment_eligibility='N/A', wip_status='UNKNOWN')


def add_time(db, r, kind, data):
    basis = data.get('time_basis', 'UNKNOWN')
    require(basis in ['UNKNOWN', 'ESTIMATED', 'USER_CONFIRMED', 'DEVICE_CONFIRMED'], 'INVALID_TIME_BASIS', '시각 근거를 확인하세요.')
    claimed = timestamp(data.get('occurred_at_claimed'))
    require(claimed is not None or basis == 'UNKNOWN', 'TIME_REQUIRED', '시각 주장 없이 시각을 확인 처리할 수 없습니다.')
    db.add(TimeRecord(run_id=r.id, event_kind=kind, occurred_at_claimed=claimed,
                      client_entered_at=timestamp(data.get('client_entered_at')), time_basis=basis,
                      evidence=data.get('time_evidence')))


def start(db, actor, data, historical=False):
    from .database import Station
    st = get(db, Station, data.get('station_id'))
    require(st.active, 'INACTIVE_STATION', '비활성 기록지점입니다.')
    model = get(db, Model, data.get('model_id'))
    require(model.active, 'INACTIVE_MODEL', '비활성 모델입니다.')
    if not historical:
        require(current(db, st.id) is None, 'STATION_BUSY', '현재 작업이 있습니다. 마감 후 시작하세요.', 409)
    kind = data.get('run_kind', 'NORMAL')
    require(kind in ['NORMAL', 'REWORK', 'REFERENCE'], 'INVALID_KIND', '작업 종류를 확인하세요.')
    id = data.get('client_run_id') or uid()
    require(isinstance(id, str) and 1 <= len(id) <= 80 and db.get(Run, id) is None,
            'RUN_ID_CONFLICT', '중복 또는 잘못된 작업 참조입니다.', 409)
    p = policy(db, st.id)
    r = Run(id=id, station_id=st.id, model_id=model.id, policy_id=p.id if p else None,
            run_kind=kind, order_ref=data.get('order_ref') or None, target_qty=qty(data.get('target_qty'), True),
            actor_id=actor, state='CLOSED' if historical else 'ACTIVE', model_snapshot={'code': model.code, 'name': model.name, 'specifications': model.specifications})
    db.add(r); db.flush()
    add_time(db, r, 'LATE_START' if historical else 'START', data)
    if not historical:
        for source in db.scalars(select(Source).where(Source.station_id == st.id)):
            if source.state in ['SHADOW', 'COMMISSIONED']:
                db.add(Activation(source_id=source.id, run_id=r.id))
    db.flush()
    result = run_dict(db, r)
    audit(db, actor, 'RUN_START', r.id, None, result)
    return r


def save_quantity(db, actor, r, data, final=False, correction=False, unreported=False, historical=False):
    check_version(r, data)
    require(r.state == ('CLOSED' if correction or historical else 'ACTIVE'), 'RUN_STATE_CONFLICT', '작업 상태가 변경되었습니다.', 409)
    old = latest(db, r)
    reason = data.get('reason')
    if correction or unreported:
        require(isinstance(reason, str) and bool(reason.strip()), 'REASON_REQUIRED', '이유를 입력하세요.')
    n = None if unreported else qty(data.get('reported_completed_qty'))
    p = db.get(Policy, r.policy_id) if r.policy_id else None
    if n is not None and p and p.state == 'CONFIRMED':
        require(n == n.quantize(Decimal(10) ** -p.decimal_places), 'UNIT_PRECISION', '설정 단위의 소수 자리수를 확인하세요.')
    if n is not None and old and old.quantity is not None and n < old.quantity:
        require(bool(reason and reason.strip()), 'DOWNWARD_REASON_REQUIRED', '하향 정정 이유가 필요합니다.')
    exceptions = data.get('exception_quantities', old.exception_quantities if old else {})
    require(isinstance(exceptions, dict) and set(exceptions) <= {'held_qty', 'scrap_qty', 'unfinished_qty'},
            'INVALID_EXCEPTIONS', '예외 수량 항목을 확인하세요.')
    exceptions = {k: dec(qty(v, True)) for k, v in exceptions.items()}
    before = run_dict(db, r)
    r.row_version += 1
    snap = Snapshot(run_id=r.id, quantity=n, delta=n - old.quantity if n is not None and old and old.quantity is not None else n,
                    version=r.row_version, is_final=final or correction, report_status='UNREPORTED' if unreported else 'REPORTED',
                    exception_quantities=exceptions, correction_of=old.id if old else None, reason=reason, actor_id=actor)
    db.add(snap)
    if final:
        r.state = 'CLOSED'; r.close_recorded_at = now()
        add_time(db, r, 'CLOSE_UNREPORTED' if unreported else 'CLOSE', data)
        # End unknown attribution ranges conservatively; only acknowledged bounds can validate events.
        for a in db.scalars(select(Activation).where(Activation.run_id == r.id, Activation.state.in_(['PREPARING','ACTIVE']))):
            a.state = 'UNRESOLVED'
    if correction:
        if 'run_kind' in data:
            require(data['run_kind'] in ['NORMAL', 'REWORK', 'REFERENCE'], 'INVALID_KIND', '작업 종류를 확인하세요.')
            r.run_kind = data['run_kind']
        if 'occurred_at_claimed' in data:
            add_time(db, r, 'CORRECTION', data)
    db.flush()
    result = run_dict(db, r)
    audit(db, actor, 'RUN_CORRECTION' if correction else ('RUN_CLOSE' if final else 'QUANTITY_SNAPSHOT'), r.id, before, result, reason)
    return result


def daily_report(db, day):
    try:
        date = datetime.fromisoformat(day).date()
    except ValueError:
        raise Rejected('INVALID_DATE', '날짜 형식을 확인하세요.')
    groups = {}
    for r in db.scalars(select(Run).where(Run.state == 'CLOSED')):
        if r.close_recorded_at.astimezone(ZoneInfo('Asia/Seoul')).date() != date:
            continue
        s = latest(db, r); p = db.get(Policy, r.policy_id) if r.policy_id else None
        # Keep station/policy/unit/kind separate; no cross-process grand total.
        key = (r.station_id, r.model_id, r.policy_id, r.run_kind)
        group = groups.setdefault(key, dict(station_id=r.station_id, model_id=r.model_id, model=r.model_snapshot,
                    run_kind=r.run_kind, policy_id=r.policy_id, unit=p.unit if p else None,
                    basis_status='CONFIRMED' if p and p.state == 'CONFIRMED' else 'COUNT_BASIS_UNCONFIRMED',
                    reported_sum=Decimal(0), run_count=0, reported_run_count=0, unreported_count=0, runs=[]))
        group['run_count'] += 1
        if s and s.quantity is not None:
            group['reported_sum'] += s.quantity
            group['reported_run_count'] += 1
        else:
            group['unreported_count'] += 1
        group['runs'].append(run_dict(db, r))
    rows = []
    for g in groups.values():
        g['reported_sum'] = dec(g['reported_sum']) if g['basis_status'] == 'CONFIRMED' and g['reported_run_count'] else None
        rows.append(g)
    return dict(day=day, time_basis='마감보고일 기준 (Asia/Seoul)', groups=rows,
                coverage='공정별 완료 신고. 양품·출하수량·고유 완제품 합계 아님.', grand_total=None,
                physical_wip='UNKNOWN', fpy='N/A', oee='N/A')
