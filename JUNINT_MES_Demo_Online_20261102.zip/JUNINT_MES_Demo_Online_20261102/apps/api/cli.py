import argparse
import getpass
import json
import os
import secrets
from pathlib import Path
from sqlalchemy import select
from .database import DatabaseIdentity, Model, Policy, Station, User, make_engine, sessions
from .main import PASSWORDS


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=['init-admin', 'seed-demo'])
    parser.add_argument('--username', default='admin')
    args = parser.parse_args()
    factory = sessions(make_engine())
    if args.command == 'init-admin':
        password = getpass.getpass('New admin password (12+ characters): ')
        if len(password) < 12:
            raise SystemExit('Password must have at least 12 characters.')
        with factory.begin() as db:
            if db.scalar(select(User).where(User.username == args.username)):
                raise SystemExit('Account exists; no changes made.')
            db.add(User(username=args.username, password_hash=PASSWORDS.hash(password), role='ADMIN'))
        print('Admin created.')
    else:
        if os.environ.get('MES_MODE') != 'DEMO':
            raise SystemExit('Synthetic seed is permitted only in a separate DEMO database.')
        p=Path('data/private/demo-credentials.json')
        with factory.begin() as db:
            identity=db.get(DatabaseIdentity,'environment')
            if identity and identity.mode != 'DEMO':
                raise SystemExit('Refusing to seed a database bound to PRODUCTION.')
            if identity is None:db.add(DatabaseIdentity(id='environment',mode='DEMO'))
            user=db.scalar(select(User).where(User.username == 'demo-admin'))
            if not user:
                password=secrets.token_urlsafe(20)
                db.add(User(username='demo-admin', password_hash=PASSWORDS.hash(password), role='ADMIN'))
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_text(json.dumps({'username':'demo-admin','password':password}));p.chmod(0o600)
            if not db.scalar(select(Model).where(Model.code == 'SYNTHETIC-001')):
                db.add_all([Model(code='SYNTHETIC-001', name='합성 데모 모델 A', aliases=['DEMO A']), Model(code='SYNTHETIC-002', name='합성 데모 모델 B')])
            if not db.scalar(select(Station).where(Station.name == '합성 데모 기록지점')):
                st=Station(name='합성 데모 기록지점', process='SYNTHETIC', final_reporting=True);db.add(st);db.flush()
                db.add(Policy(station_id=st.id, version=1, unit='EA', boundary='합성 데모 완료 경계', inclusion='데모 신고수량이며 실제 회사 기준이 아님', state='CONFIRMED'))
        print('DEMO fixture ready. Local credentials: data/private/demo-credentials.json (never commit).')


if __name__ == '__main__':
    main()
