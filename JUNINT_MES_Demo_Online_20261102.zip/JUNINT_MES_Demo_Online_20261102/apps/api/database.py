import os
from datetime import datetime, timezone
from uuid import uuid4

from sqlalchemy import DateTime, ForeignKey, Integer, Numeric, String, Text, UniqueConstraint, create_engine, text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker


def now():
    return datetime.now(timezone.utc)


def uid():
    return str(uuid4())


class Base(DeclarativeBase):
    pass


class DatabaseIdentity(Base):
    __tablename__ = 'database_identity'
    id: Mapped[str] = mapped_column(String, primary_key=True)
    mode: Mapped[str] = mapped_column(String)


class User(Base):
    __tablename__ = 'users'
    id: Mapped[str] = mapped_column(String, primary_key=True, default=uid)
    username: Mapped[str] = mapped_column(String, unique=True)
    password_hash: Mapped[str] = mapped_column(Text)
    role: Mapped[str] = mapped_column(String)
    active: Mapped[bool] = mapped_column(default=True)


class LoginSession(Base):
    __tablename__ = 'login_sessions'
    token_hash: Mapped[str] = mapped_column(String, primary_key=True)
    user_id: Mapped[str] = mapped_column(ForeignKey('users.id'))
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))


class Model(Base):
    __tablename__ = 'models'
    id: Mapped[str] = mapped_column(String, primary_key=True, default=uid)
    code: Mapped[str] = mapped_column(String, unique=True)
    name: Mapped[str] = mapped_column(String)
    aliases: Mapped[list] = mapped_column(JSONB, default=list)
    specifications: Mapped[dict] = mapped_column(JSONB, default=dict)
    active: Mapped[bool] = mapped_column(default=True)


class Favorite(Base):
    __tablename__ = 'favorites'
    user_id: Mapped[str] = mapped_column(ForeignKey('users.id'), primary_key=True)
    model_id: Mapped[str] = mapped_column(ForeignKey('models.id'), primary_key=True)


class Station(Base):
    __tablename__ = 'stations'
    id: Mapped[str] = mapped_column(String, primary_key=True, default=uid)
    name: Mapped[str] = mapped_column(String, unique=True)
    process: Mapped[str] = mapped_column(String)
    final_reporting: Mapped[bool] = mapped_column(default=False)
    active: Mapped[bool] = mapped_column(default=True)


class Policy(Base):
    __tablename__ = 'measurement_policies'
    __table_args__ = (UniqueConstraint('station_id', 'version'),)
    id: Mapped[str] = mapped_column(String, primary_key=True, default=uid)
    station_id: Mapped[str] = mapped_column(ForeignKey('stations.id'))
    version: Mapped[int] = mapped_column(Integer)
    unit: Mapped[str | None] = mapped_column(String)
    boundary: Mapped[str | None] = mapped_column(Text)
    inclusion: Mapped[str | None] = mapped_column(Text)
    decimal_places: Mapped[int] = mapped_column(Integer, default=0)
    state: Mapped[str] = mapped_column(String, default='UNCONFIRMED')
    recorded_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)


class Run(Base):
    __tablename__ = 'production_runs'
    id: Mapped[str] = mapped_column(String, primary_key=True, default=uid)
    station_id: Mapped[str] = mapped_column(ForeignKey('stations.id'), index=True)
    model_id: Mapped[str] = mapped_column(ForeignKey('models.id'))
    policy_id: Mapped[str | None] = mapped_column(ForeignKey('measurement_policies.id'))
    row_version: Mapped[int] = mapped_column(Integer, default=1)
    state: Mapped[str] = mapped_column(String, default='ACTIVE')
    coverage_mode: Mapped[str] = mapped_column(String, default='RUN_OBSERVATION')
    run_kind: Mapped[str] = mapped_column(String, default='NORMAL')
    order_ref: Mapped[str | None] = mapped_column(String)
    target_qty: Mapped[object | None] = mapped_column(Numeric(24, 6))
    model_snapshot: Mapped[dict] = mapped_column(JSONB, default=dict)
    started_recorded_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    close_recorded_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)
    actor_id: Mapped[str] = mapped_column(ForeignKey('users.id'))


class TimeRecord(Base):
    __tablename__ = 'run_time_records'
    id: Mapped[str] = mapped_column(String, primary_key=True, default=uid)
    run_id: Mapped[str] = mapped_column(ForeignKey('production_runs.id'))
    event_kind: Mapped[str] = mapped_column(String)
    occurred_at_claimed: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    time_basis: Mapped[str] = mapped_column(String, default='UNKNOWN')
    client_entered_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    recorded_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    evidence: Mapped[str | None] = mapped_column(Text)


class Snapshot(Base):
    __tablename__ = 'run_quantity_snapshots'
    id: Mapped[str] = mapped_column(String, primary_key=True, default=uid)
    run_id: Mapped[str] = mapped_column(ForeignKey('production_runs.id'), index=True)
    quantity: Mapped[object | None] = mapped_column(Numeric(24, 6))
    delta: Mapped[object | None] = mapped_column(Numeric(24, 6))
    report_status: Mapped[str] = mapped_column(String, default='REPORTED')
    is_final: Mapped[bool] = mapped_column(default=False)
    version: Mapped[int] = mapped_column(Integer)
    exception_quantities: Mapped[dict] = mapped_column(JSONB, default=dict)
    correction_of: Mapped[str | None] = mapped_column(String)
    reason: Mapped[str | None] = mapped_column(Text)
    recorded_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    actor_id: Mapped[str] = mapped_column(ForeignKey('users.id'))


class Prepared(Base):
    __tablename__ = 'prepared_jobs'
    id: Mapped[str] = mapped_column(String, primary_key=True, default=uid)
    station_id: Mapped[str] = mapped_column(ForeignKey('stations.id'))
    model_id: Mapped[str] = mapped_column(ForeignKey('models.id'))
    state: Mapped[str] = mapped_column(String, default='READY')
    row_version: Mapped[int] = mapped_column(Integer, default=1)
    position: Mapped[int] = mapped_column(Integer, default=0)
    target_qty: Mapped[object | None] = mapped_column(Numeric(24, 6))
    order_ref: Mapped[str | None] = mapped_column(String)


class Command(Base):
    __tablename__ = 'commands'
    key: Mapped[str] = mapped_column(String, primary_key=True)
    actor_id: Mapped[str] = mapped_column(String)
    digest: Mapped[str] = mapped_column(String)
    response: Mapped[dict] = mapped_column(JSONB)
    status: Mapped[int] = mapped_column(Integer, default=200)
    recorded_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)


class Audit(Base):
    __tablename__ = 'audit_events'
    id: Mapped[str] = mapped_column(String, primary_key=True, default=uid)
    actor_id: Mapped[str] = mapped_column(String)
    action: Mapped[str] = mapped_column(String)
    entity_id: Mapped[str | None] = mapped_column(String)
    before: Mapped[dict | None] = mapped_column(JSONB)
    after: Mapped[dict] = mapped_column(JSONB)
    reason: Mapped[str | None] = mapped_column(Text)
    recorded_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)


class Conflict(Base):
    __tablename__ = 'review_conflicts'
    id: Mapped[str] = mapped_column(String, primary_key=True, default=uid)
    actor_id: Mapped[str] = mapped_column(String)
    command_key: Mapped[str] = mapped_column(String)
    request: Mapped[dict] = mapped_column(JSONB)
    reason: Mapped[str] = mapped_column(Text)
    state: Mapped[str] = mapped_column(String, default='OPEN')
    recorded_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)


class Source(Base):
    __tablename__ = 'sources'
    id: Mapped[str] = mapped_column(String, primary_key=True, default=uid)
    station_id: Mapped[str] = mapped_column(ForeignKey('stations.id'))
    stream_id: Mapped[str] = mapped_column(String)
    name: Mapped[str] = mapped_column(String)
    state: Mapped[str] = mapped_column(String, default='UNCONFIGURED')
    capabilities: Mapped[list] = mapped_column(JSONB, default=list)
    token_hash: Mapped[str | None] = mapped_column(String, unique=True)
    contract: Mapped[dict] = mapped_column(JSONB, default=dict)
    last_received_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class Activation(Base):
    __tablename__ = 'source_activations'
    id: Mapped[str] = mapped_column(String, primary_key=True, default=uid)
    source_id: Mapped[str] = mapped_column(ForeignKey('sources.id'))
    run_id: Mapped[str] = mapped_column(ForeignKey('production_runs.id'))
    state: Mapped[str] = mapped_column(String, default='PREPARING')
    file_generation: Mapped[str | None] = mapped_column(String)
    lower_sequence: Mapped[int | None] = mapped_column(Integer)
    upper_sequence: Mapped[int | None] = mapped_column(Integer)
    evidence: Mapped[dict] = mapped_column(JSONB, default=dict)


class Capture(Base):
    __tablename__ = 'raw_captures'
    id: Mapped[str] = mapped_column(String, primary_key=True, default=uid)
    source_id: Mapped[str] = mapped_column(ForeignKey('sources.id'))
    sha256: Mapped[str] = mapped_column(String)
    storage_key: Mapped[str] = mapped_column(String)
    size: Mapped[int] = mapped_column(Integer)
    parse_status: Mapped[str] = mapped_column(String, default='UNPARSED')
    parser_error: Mapped[str | None] = mapped_column(Text)
    received_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)


class Inspection(Base):
    __tablename__ = 'integration_events'
    __table_args__ = (UniqueConstraint('source_id', 'stream_id', 'source_event_key'),)
    id: Mapped[str] = mapped_column(String, primary_key=True)
    source_id: Mapped[str] = mapped_column(ForeignKey('sources.id'))
    stream_id: Mapped[str] = mapped_column(String)
    source_event_key: Mapped[str] = mapped_column(String)
    payload_hash: Mapped[str] = mapped_column(String)
    raw_payload: Mapped[dict] = mapped_column(JSONB)
    run_id: Mapped[str | None] = mapped_column(ForeignKey('production_runs.id'))
    validated_attribution: Mapped[str] = mapped_column(String, default='UNRESOLVED')
    processing_status: Mapped[str] = mapped_column(String, default='PENDING')
    review_reason: Mapped[str | None] = mapped_column(Text)
    received_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)


class Wip(Base):
    __tablename__ = 'wip_observations'
    id: Mapped[str] = mapped_column(String, primary_key=True, default=uid)
    station_id: Mapped[str] = mapped_column(ForeignKey('stations.id'))
    status: Mapped[str] = mapped_column(String)
    quantity: Mapped[object | None] = mapped_column(Numeric(24, 6))
    unit: Mapped[str | None] = mapped_column(String)
    evidence: Mapped[str | None] = mapped_column(Text)
    recorded_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)


class Support(Base):
    __tablename__ = 'support_requests'
    id: Mapped[str] = mapped_column(String, primary_key=True, default=uid)
    station_id: Mapped[str] = mapped_column(ForeignKey('stations.id'))
    run_id: Mapped[str | None] = mapped_column(ForeignKey('production_runs.id'))
    message: Mapped[str] = mapped_column(Text)
    state: Mapped[str] = mapped_column(String, default='OPEN')
    recorded_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)


def make_engine(url=None):
    url = url or os.environ.get('DATABASE_URL')
    if not url or not url.startswith('postgresql'):
        raise RuntimeError('Set DATABASE_URL to a PostgreSQL database; SQLite is edge-spool only.')
    return create_engine(url, pool_pre_ping=True)


def sessions(engine):
    return sessionmaker(engine, expire_on_commit=False)
