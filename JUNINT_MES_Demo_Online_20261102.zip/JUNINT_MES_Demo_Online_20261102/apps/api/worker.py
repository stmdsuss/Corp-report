"""Persistent PostgreSQL inbox consumer. Never infer attribution from CURRENT."""
import time
from sqlalchemy import select
from .database import Activation, DatabaseIdentity, Inspection, Run, Source, make_engine, sessions


def process_pending(factory):
    count = 0
    with factory.begin() as db:
        events = db.scalars(select(Inspection).where(Inspection.processing_status == 'PENDING').with_for_update(skip_locked=True).limit(100)).all()
        for e in events:
            d = e.raw_payload; s = db.get(Source, e.source_id)
            e.processing_status = 'REVIEW_REQUIRED'; e.review_reason = '검증된 원본 경계가 없어 설비 기록으로 보존합니다.'
            a = db.get(Activation, d.get('source_activation_id')) if d.get('source_activation_id') else None
            try:
                generation, sequence = d.get('source_cursor', '').rsplit(':', 1)
                sequence = int(sequence)
            except (ValueError, AttributeError):
                generation, sequence = None, None
            valid = (s.state == 'COMMISSIONED' and 'RUN_ATTRIBUTION' in s.capabilities
                     and s.contract.get('async_safe') is True and bool(s.contract.get('approval_ref'))
                     and a is not None and a.source_id == s.id and a.state in ['ACTIVE', 'CLOSED']
                     and generation == a.file_generation and sequence is not None
                     and a.lower_sequence is not None and sequence > a.lower_sequence
                     and (a.upper_sequence is None or sequence <= a.upper_sequence)
                     and d.get('run_id') == a.run_id
                     and d.get('attribution_level') == 'RUN'
                     and d.get('evidence', {}).get('attribution_method') in ['SOURCE_CURSOR', 'APPROVED_RUN_CONTEXT'])
            if valid:
                r = db.get(Run, a.run_id)
                model_ok = (not d.get('model_id') or d['model_id'] == r.model_id) and (not d.get('native_model_code') or d['native_model_code'] == r.model_snapshot['code'])
                known_program=r.model_snapshot.get('specifications',{}).get('program_revision')
                if known_program and d.get('program_revision') and d['program_revision'] != known_program:
                    model_ok=False
                if model_ok:
                    e.run_id = r.id; e.validated_attribution = 'RUN'; e.processing_status = 'PROCESSED'; e.review_reason = None
                else:
                    e.review_reason = '신고 모델과 검사 원본 모델이 충돌합니다. 최소 구분 확인이 필요합니다.'
            count += 1
    return count


if __name__ == '__main__':
    factory = sessions(make_engine())
    import os
    with factory() as db:
        identity=db.get(DatabaseIdentity,'environment')
        if identity and identity.mode != os.environ.get('MES_MODE','PRODUCTION'):
            raise SystemExit('Database environment mismatch')
    while True:
        try:
            process_pending(factory)
        except Exception:
            # Transaction rollback retains PENDING rows for the next attempt.
            import logging
            logging.exception('Inbox processing failed; retrying')
        time.sleep(2)
