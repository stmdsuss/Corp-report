import base64
import hashlib
import json
import os
import secrets
from datetime import timedelta
from pathlib import Path

from argon2 import PasswordHasher
from argon2.exceptions import VerificationError
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from jsonschema import Draft202012Validator, FormatChecker
from sqlalchemy import func, select, text
from sqlalchemy.exc import IntegrityError

from .database import (Activation, Audit, Capture, Command, Conflict, DatabaseIdentity, Favorite, Inspection,
                       LoginSession, Model, Policy, Prepared, Run, Snapshot, Source, Station,
                       Support, User, Wip, make_engine, now, sessions, uid)
from .domain import (Rejected, add_time, audit, check_version, current, daily_report, dec, get,
                     latest, policy, qty, require, run_dict, save_quantity, start, timestamp)

PASSWORDS = PasswordHasher()
SCHEMA = Draft202012Validator(json.loads(Path(__file__).with_name('inspection_event.schema.json').read_text()), format_checker=FormatChecker())


def digest(value):
    return hashlib.sha256(value.encode()).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False)


def safe_body(data):
    return {k: '[REDACTED]' if k.lower() in ['password', 'device_key', 'token'] else v for k, v in data.items()}


def durable_original(root, sha, raw):
    file=root/sha
    quarantine=None
    if file.exists():
        if hashlib.sha256(file.read_bytes()).hexdigest()!=sha:
            quarantine=sha+'.corrupt.'+uid()
            file.replace(root/quarantine)
        else:
            os.chmod(file,0o600)
            with file.open('rb') as f:os.fsync(f.fileno())
    if not file.exists():
        temp=root/(sha+'.'+uid()+'.tmp')
        try:
            fd=os.open(temp,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
            with os.fdopen(fd,'wb') as f:
                f.write(raw);f.flush();os.fsync(f.fileno())
            os.replace(temp,file)
        finally:
            temp.unlink(missing_ok=True)
    fd=os.open(root,os.O_RDONLY|os.O_DIRECTORY)
    try:os.fsync(fd)
    finally:os.close(fd)
    return quarantine


def source_dict(s):
    return dict(id=s.id, station_id=s.station_id, stream_id=s.stream_id, name=s.name, state=s.state,
                capabilities=s.capabilities, contract=s.contract,
                last_received_at=s.last_received_at.isoformat() if s.last_received_at else None,
                reception_status='NEVER_RECEIVED' if not s.last_received_at else 'RECEIVED')


def model_dict(m):
    return dict(id=m.id, code=m.code, name=m.name, aliases=m.aliases,
                specifications=m.specifications, active=m.active)


def prepared_dict(p):
    return dict(id=p.id, station_id=p.station_id, model_id=p.model_id, state=p.state,
                row_version=p.row_version, position=p.position, order_ref=p.order_ref, target_qty=dec(p.target_qty))


def principal(db, request):
    auth = request.headers.get('Authorization', '')
    if auth.startswith('Bearer '):
        source = db.scalar(select(Source).where(Source.token_hash == digest(auth[7:])))
        require(source is not None and source.state != 'SUSPENDED', 'UNAUTHORIZED', '장치 인증이 필요합니다.', 401)
        return {'id': 'device:' + source.id, 'role': 'DEVICE', 'source_id': source.id}
    token = request.cookies.get('mes_session')
    session = db.get(LoginSession, digest(token)) if token else None
    user = db.get(User, session.user_id) if session and session.expires_at > now() else None
    require(user is not None and user.active, 'UNAUTHORIZED', '로그인이 필요합니다.', 401)
    return {'id': user.id, 'role': user.role, 'username': user.username}


def role(actor, *allowed):
    require(actor['role'] in allowed, 'FORBIDDEN', '이 작업에 대한 권한이 없습니다.', 403)


async def bounded_json(request, limit=3_000_000):
    chunks=[];size=0
    async for chunk in request.stream():
        size+=len(chunk)
        require(size<=limit,'PAYLOAD_TOO_LARGE','요청 크기 제한을 초과했습니다.',413)
        chunks.append(chunk)
    try: data=json.loads(b''.join(chunks))
    except (ValueError,UnicodeError): raise Rejected('INVALID_JSON','JSON 형식을 확인하세요.')
    require(isinstance(data,dict),'INVALID_BODY','객체 형식이 필요합니다.')
    return data


def create_app(engine=None, mode=None, attachment_root=None):
    engine = engine or make_engine()
    factory = sessions(engine)
    mode = mode or os.environ.get('MES_MODE', 'PRODUCTION')
    require(mode in ['DEMO', 'PRODUCTION'], 'INVALID_MODE', '운영 모드를 확인하세요.')
    with factory.begin() as db:
        db.execute(text('SELECT pg_advisory_xact_lock(747215901)'))
        identity=db.get(DatabaseIdentity,'environment')
        if identity is None:
            db.add(DatabaseIdentity(id='environment',mode=mode))
        elif identity.mode != mode:
            raise RuntimeError('Database environment mismatch: use separate DEMO and PRODUCTION databases.')
    root = Path(attachment_root or os.environ.get('ATTACHMENT_ROOT', f'var/attachments/{mode}')).resolve()
    root.mkdir(parents=True, exist_ok=True)
    app = FastAPI(title='준아이엔티 MES — 작업기록', version='0.1.0')
    app.state.factory, app.state.engine, app.state.mode = factory, engine, mode
    app.state.attachment_root = root

    @app.exception_handler(Rejected)
    async def rejected(request, exc):
        return JSONResponse({'code': exc.code, 'message': exc.message}, status_code=exc.status)

    @app.middleware('http')
    async def boundaries(request, call_next):
        length = request.headers.get('content-length')
        if length and (not length.isdigit() or int(length) > 3_000_000):
            return JSONResponse({'code': 'PAYLOAD_TOO_LARGE'}, status_code=413)
        if request.method not in ['GET', 'HEAD', 'OPTIONS']:
            origin = request.headers.get('origin')
            expected_origin=os.environ.get('PUBLIC_ORIGIN') or str(request.base_url)
            if origin and origin.rstrip('/') != expected_origin.rstrip('/'):
                return JSONResponse({'code': 'ORIGIN_REJECTED'}, status_code=403)
            if 'application/json' not in request.headers.get('content-type', ''):
                return JSONResponse({'code': 'JSON_REQUIRED'}, status_code=415)
        response = await call_next(request)
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['Cache-Control'] = 'no-store'
        return response

    @app.get('/health')
    def health():
        with engine.connect() as c:
            c.execute(text('SELECT 1'))
        return {'status': 'ok', 'mode': mode}

    @app.post('/api/v2/auth/login')
    async def login(request: Request):
        data = await bounded_json(request,8192)
        with factory.begin() as db:
            # Throttle persistent failed attempts per account. No password or token is audited.
            username = str(data.get('username', ''))[:120]
            recent = db.scalar(select(func.count()).select_from(Audit).where(
                Audit.action == 'LOGIN_FAILURE', Audit.actor_id == username, Audit.recorded_at > now() - timedelta(minutes=5)))
            require(recent < 10, 'RATE_LIMIT', '잠시 후 다시 로그인하세요.', 429)
            user = db.scalar(select(User).where(User.username == username, User.active.is_(True)))
            ok = False
            if user:
                try:
                    ok = PASSWORDS.verify(user.password_hash, str(data.get('password', '')))
                except VerificationError:
                    pass
            if not ok:
                audit(db, username, 'LOGIN_FAILURE', None, None, {})
                return JSONResponse({'code': 'INVALID_LOGIN', 'message': '로그인 정보를 확인하세요.'}, status_code=401)
            token = secrets.token_urlsafe(40)
            db.add(LoginSession(token_hash=digest(token), user_id=user.id, expires_at=now() + timedelta(hours=12)))
            audit(db, user.id, 'LOGIN', user.id, None, {})
            response = JSONResponse({'id': user.id, 'role': user.role, 'username': user.username})
            response.set_cookie('mes_session', token, httponly=True, samesite='strict',
                                secure=os.environ.get('COOKIE_SECURE', '1' if mode == 'PRODUCTION' else '0') == '1', max_age=43200)
            return response

    @app.post('/api/v2/auth/logout')
    async def logout(request: Request):
        with factory.begin() as db:
            token = request.cookies.get('mes_session')
            row = db.get(LoginSession, digest(token)) if token else None
            if row:
                db.delete(row)
        response = JSONResponse({'status': 'ok'}); response.delete_cookie('mes_session'); return response

    @app.get('/api/v2/{path:path}')
    def read(path: str, request: Request):
        with factory() as db:
            actor = principal(db, request)
            if actor['role']=='DEVICE' and path=='source-activations/pending':
                return [dict(id=a.id,run_id=a.run_id,state=a.state) for a in db.scalars(select(Activation).where(Activation.source_id==actor['source_id'],Activation.state=='PREPARING'))]
            role(actor, 'ADMIN', 'SUPERVISOR', 'OPERATOR', 'VIEWER')
            bits = path.split('/')
            if path == 'auth/me':
                return {**actor, 'mode': mode}
            if path == 'models':
                q = request.query_params.get('q', '').casefold()
                favorites = set(db.scalars(select(Favorite.model_id).where(Favorite.user_id == actor['id'])))
                return [{**model_dict(m), 'favorite': m.id in favorites} for m in db.scalars(select(Model).order_by(Model.code))
                        if q in canonical(model_dict(m)).casefold()]
            if path == 'stations':
                return [dict(id=s.id, name=s.name, process=s.process, final_reporting=s.final_reporting, active=s.active,
                             policy=policy_dict(policy(db, s.id))) for s in db.scalars(select(Station).order_by(Station.name))]
            if len(bits) == 3 and bits[0] == 'stations' and bits[2] == 'board':
                st = get(db, Station, bits[1]); r = current(db, st.id)
                runs = db.scalars(select(Run).where(Run.station_id == st.id).order_by(Run.started_recorded_at.desc()).limit(20)).all()
                recent_ids = list(dict.fromkeys(x.model_id for x in runs))[:6]
                sources = db.scalars(select(Source).where(Source.station_id == st.id)).all()
                return dict(station=dict(id=st.id, name=st.name, process=st.process),
                            current=run_dict(db, r) if r else None,
                            next=[prepared_dict(p) for p in db.scalars(select(Prepared).where(Prepared.station_id == st.id, Prepared.state == 'READY').order_by(Prepared.position, Prepared.id))],
                            recent_models=[model_dict(db.get(Model, x)) for x in recent_ids],
                            recently_closed=[run_dict(db, x) for x in runs if x.state == 'CLOSED'][:8],
                            policy=policy_dict(policy(db, st.id)), sources=[source_dict(s) for s in sources],
                            collection_status='UNCONFIGURED' if not sources else ('PENDING' if any(a.state == 'PREPARING' for a in db.scalars(select(Activation).join(Source).where(Source.station_id == st.id))) else 'CONFIGURED'),
                            support=[dict(id=s.id, message=s.message, state=s.state) for s in db.scalars(select(Support).where(Support.station_id == st.id, Support.state == 'OPEN'))],
                            limitations='완료 신고는 양품·출하승인·실물 LOT 추적이 아닙니다.')
            if len(bits) == 2 and bits[0] == 'runs':
                return run_dict(db, get(db, Run, bits[1]))
            if len(bits) == 3 and bits[0] == 'runs' and bits[2] == 'history':
                get(db, Run, bits[1])
                return [dict(id=s.id, quantity=dec(s.quantity), delta=dec(s.delta), version=s.version,
                             report_status=s.report_status, is_final=s.is_final, reason=s.reason,
                             exception_quantities=s.exception_quantities, correction_of=s.correction_of,
                             recorded_at=s.recorded_at.isoformat()) for s in db.scalars(select(Snapshot).where(Snapshot.run_id == bits[1]).order_by(Snapshot.version))]
            if path == 'reports/daily-close':
                return daily_report(db, request.query_params.get('day', now().astimezone(__import__('zoneinfo').ZoneInfo('Asia/Seoul')).date().isoformat()))
            if path == 'wip-observations':
                return [dict(station_id=st.id, status=w.status if w else 'UNKNOWN', quantity=dec(w.quantity) if w else None,
                             unit=w.unit if w else None, evidence=w.evidence if w else None,
                             recorded_at=w.recorded_at.isoformat() if w else None)
                        for st in db.scalars(select(Station))
                        for w in [db.scalar(select(Wip).where(Wip.station_id == st.id).order_by(Wip.recorded_at.desc()))]]
            if path == 'sources':
                return [source_dict(s) for s in db.scalars(select(Source))]
            if path == 'source-activations':
                return [dict(id=a.id, source_id=a.source_id, run_id=a.run_id, state=a.state,
                             file_generation=a.file_generation, lower_sequence=a.lower_sequence,
                             upper_sequence=a.upper_sequence, evidence=a.evidence) for a in db.scalars(select(Activation))]
            if path == 'integration/events':
                return [dict(id=e.id, source_id=e.source_id, raw_payload=e.raw_payload,
                             validated_attribution=e.validated_attribution, run_id=e.run_id,
                             processing_status=e.processing_status, review_reason=e.review_reason,
                             received_at=e.received_at.isoformat()) for e in db.scalars(select(Inspection).order_by(Inspection.received_at.desc()).limit(200))]
            if path=='integration/raw-captures':
                return [dict(id=c.id,source_id=c.source_id,sha256=c.sha256,size=c.size,
                             parse_status=c.parse_status,parser_error=c.parser_error,received_at=c.received_at.isoformat())
                        for c in db.scalars(select(Capture).order_by(Capture.received_at.desc()).limit(200))]
            if len(bits)==3 and bits[:2]==['integration','raw-captures']:
                role(actor,'ADMIN','SUPERVISOR');c=get(db,Capture,bits[2]);file=(root/c.storage_key).resolve()
                require(file.is_relative_to(root) and file.is_file(),'ORIGINAL_NOT_FOUND','원본 파일을 찾을 수 없습니다.',404)
                from fastapi.responses import FileResponse
                return FileResponse(file,filename=c.sha256+'.bin',media_type='application/octet-stream')
            if path == 'integration/stats':
                events = db.scalars(select(Inspection)).all()
                eligible = [e for e in events if e.raw_payload.get('test_mode') == 'PRODUCTION' and e.run_id
                            and db.get(Run, e.run_id).run_kind == 'NORMAL']
                return dict(attempts=len(events), unresolved=sum(e.run_id is None for e in events),
                            eligible_production_attempts=len(eligible),
                            pass_attempts=sum(e.raw_payload.get('raw_result') == 'PASS' for e in eligible),
                            fpy='N/A', quantity_effect='NONE')
            if path == 'conflicts':
                role(actor, 'ADMIN', 'SUPERVISOR')
                return [dict(id=c.id, request=c.request, reason=c.reason, state=c.state) for c in db.scalars(select(Conflict).order_by(Conflict.recorded_at.desc()).limit(200))]
            if path == 'audit':
                role(actor, 'ADMIN', 'SUPERVISOR')
                return [dict(id=a.id, action=a.action, entity_id=a.entity_id, before=a.before, after=a.after,
                             reason=a.reason, actor_id=a.actor_id, recorded_at=a.recorded_at.isoformat())
                        for a in db.scalars(select(Audit).order_by(Audit.recorded_at.desc()).limit(300))]
            if path == 'users':
                role(actor, 'ADMIN')
                return [dict(id=u.id, username=u.username, role=u.role, active=u.active) for u in db.scalars(select(User))]
            if path == 'features':
                return {'RUN_OBSERVATION': 'IMPLEMENTED', 'IDENTIFIED_FLOW': 'NOT_IMPLEMENTED',
                        'UNIT_TRACE': 'NOT_IMPLEMENTED', 'quality_release': 'N/A', 'shipment_gate': 'N/A', 'erp': 'UNCONFIGURED'}
            raise Rejected('NOT_FOUND', 'API 경로가 없습니다.', 404)

    @app.api_route('/api/v2/{path:path}', methods=['POST', 'PATCH'])
    async def mutate(path: str, request: Request):
        data = await bounded_json(request)
        key = request.headers.get('Idempotency-Key', '')
        require(1 <= len(key) <= 160, 'COMMAND_KEY_REQUIRED', '명령ID가 필요합니다.')
        with factory.begin() as db:
            actor = principal(db, request)
            expected_actor=request.headers.get('X-MES-Actor');expected_mode=request.headers.get('X-MES-Mode')
            require(not expected_actor or expected_actor==actor['id'],'ACTOR_CONTEXT_CHANGED','로그인 계정이 바뀌어 이전 기록 전송을 중지했습니다.',409)
            require(not expected_mode or expected_mode==mode,'ENVIRONMENT_CONTEXT_CHANGED','환경이 바뀌어 이전 기록 전송을 중지했습니다.',409)
            if actor['role'] == 'DEVICE':
                require(path in ['integration/events', 'integration/raw-captures'] or
                        (path.startswith('source-activations/') and path.endswith('/ack')), 'FORBIDDEN', '장치는 지정 원본 제출만 가능합니다.', 403)
            else:
                role(actor, 'ADMIN', 'SUPERVISOR', 'OPERATOR')
            # Small-factory modular monolith: one DB transaction lock serializes mutations.
            # Read endpoints stay concurrent. This also closes idempotency check/insert races.
            db.execute(text('SELECT pg_advisory_xact_lock(747215901)'))
            h = digest(request.method + ':' + path + ':' + canonical(data))
            existing = db.get(Command, key)
            if existing:
                if existing.digest == h and existing.actor_id == actor['id']:
                    return JSONResponse(existing.response, status_code=existing.status)
                c = Conflict(actor_id=actor['id'], command_key=key, request={'path': path, 'body': safe_body(data)}, reason='IDEMPOTENCY_CONFLICT')
                db.add(c); db.flush()
                return JSONResponse({'code': 'IDEMPOTENCY_CONFLICT', 'message': '같은 명령ID에 다른 요청입니다.', 'conflict_id': c.id}, status_code=409)
            try:
                with db.begin_nested():
                    result, status = dispatch(db, actor, path, request.method, data, mode, root)
            except Rejected as exc:
                if exc.status != 409:
                    raise
                conflict = Conflict(actor_id=actor['id'], command_key=key, request={'path': path, 'body': safe_body(data)}, reason=exc.code)
                db.add(conflict); db.flush()
                result, status = {'code': exc.code, 'message': exc.message, 'conflict_id': conflict.id}, 409
            except IntegrityError:
                conflict = Conflict(actor_id=actor['id'], command_key=key, request={'path': path, 'body': safe_body(data)}, reason='DATABASE_CONFLICT')
                db.add(conflict); db.flush()
                result, status = {'code': 'DATABASE_CONFLICT', 'message': '중복·동시 변경이 검토함에 보존되었습니다.', 'conflict_id': conflict.id}, 409
            db.add(Command(key=key, actor_id=actor['id'], digest=h, response=result, status=status))
            return JSONResponse(result, status_code=status)
    web = Path(__file__).resolve().parents[1] / 'web' / 'dist'
    if web.is_dir():
        from fastapi.staticfiles import StaticFiles
        app.mount('/', StaticFiles(directory=web, html=True), name='web')
    return app


def policy_dict(p):
    return dict(id=p.id, unit=p.unit, boundary=p.boundary, inclusion=p.inclusion, state=p.state,
                version=p.version, decimal_places=p.decimal_places) if p else None


def dispatch(db, actor, path, method, d, mode, root):
    bits = path.split('/'); who = actor['id']
    if path == 'models':
        role(actor, 'ADMIN')
        require(isinstance(d.get('code'), str) and d['code'].strip() and isinstance(d.get('name'), str) and d['name'].strip(), 'MODEL_REQUIRED', '모델코드와 이름이 필요합니다.')
        require(isinstance(d.get('aliases', []), list) and all(isinstance(a, str) for a in d.get('aliases', [])), 'INVALID_ALIAS', '별칭은 문자열 목록입니다.')
        require(isinstance(d.get('specifications', {}), dict), 'INVALID_SPEC', '구분사양은 객체입니다.')
        m = Model(code=d['code'].strip(), name=d['name'].strip(), aliases=d.get('aliases', []), specifications=d.get('specifications', {}))
        db.add(m); db.flush(); result = model_dict(m)
        audit(db, who, 'MODEL_CREATE', m.id, None, result); return result, 201
    if len(bits) == 3 and bits[0] == 'models' and bits[2] == 'favorite':
        role(actor, 'ADMIN', 'SUPERVISOR', 'OPERATOR'); get(db, Model, bits[1])
        row = db.get(Favorite, (who, bits[1]))
        if d.get('favorite', True) and not row: db.add(Favorite(user_id=who, model_id=bits[1]))
        if not d.get('favorite', True) and row: db.delete(row)
        return {'favorite': bool(d.get('favorite', True))}, 200
    if len(bits) == 2 and bits[0] == 'models':
        role(actor, 'ADMIN'); m=get(db, Model, bits[1]); before=model_dict(m)
        for key in ['name', 'code']:
            if key in d:
                require(isinstance(d[key], str) and bool(d[key].strip()), 'MODEL_REQUIRED', '코드·표시명을 확인하세요.')
                setattr(m, key, d[key].strip())
        if 'aliases' in d:
            require(isinstance(d['aliases'], list) and all(isinstance(a,str) for a in d['aliases']), 'INVALID_ALIAS', '별칭을 확인하세요.')
            m.aliases=d['aliases']
        if 'specifications' in d:
            require(isinstance(d['specifications'],dict), 'INVALID_SPEC', '사양을 확인하세요.');m.specifications=d['specifications']
        if 'active' in d: m.active=bool(d['active'])
        audit(db,who,'MODEL_UPDATE',m.id,before,model_dict(m));return model_dict(m),200
    if path == 'stations':
        role(actor, 'ADMIN')
        require(bool(d.get('name')) and bool(d.get('process')), 'STATION_REQUIRED', '기록지점 이름과 공정이 필요합니다.')
        st = Station(name=d['name'], process=d['process'], final_reporting=bool(d.get('final_reporting', False)))
        db.add(st); db.flush(); audit(db, who, 'STATION_CREATE', st.id, None, d); return {'id': st.id, 'name': st.name}, 201
    if len(bits) == 3 and bits[0] == 'stations' and bits[2] == 'policies':
        role(actor, 'ADMIN'); get(db, Station, bits[1]); old = policy(db, bits[1])
        confirmed = d.get('state', 'UNCONFIRMED') == 'CONFIRMED'
        require(d.get('state', 'UNCONFIRMED') in ['CONFIRMED', 'UNCONFIRMED'], 'INVALID_STATE', '정책 상태를 확인하세요.')
        require(not confirmed or all(isinstance(d.get(k), str) and d[k].strip() for k in ['unit', 'boundary', 'inclusion']), 'POLICY_REQUIRED', '확정 정책은 단위·완료 경계·포함범위가 필요합니다.')
        places = d.get('decimal_places', 0)
        require(type(places) is int and 0 <= places <= 6, 'INVALID_PRECISION', '소수 자리는 0~6입니다.')
        p = Policy(station_id=bits[1], version=old.version+1 if old else 1, unit=d.get('unit'), boundary=d.get('boundary'), inclusion=d.get('inclusion'), decimal_places=places, state=d.get('state', 'UNCONFIRMED'))
        db.add(p); db.flush(); audit(db, who, 'POLICY_REVISION', p.id, policy_dict(old), policy_dict(p)); return policy_dict(p), 201
    if path == 'prepared-jobs':
        get(db, Station, d.get('station_id')); get(db, Model, d.get('model_id'))
        require(type(d.get('position',0)) is int,'INVALID_POSITION','준비 순서를 확인하세요.')
        p = Prepared(station_id=d['station_id'], model_id=d['model_id'], position=d.get('position', 0), target_qty=qty(d.get('target_qty'), True), order_ref=d.get('order_ref'))
        db.add(p); db.flush(); audit(db, who, 'PREPARED_CREATE', p.id, None, prepared_dict(p)); return prepared_dict(p), 201
    if len(bits) == 2 and bits[0] == 'prepared-jobs':
        p = get(db, Prepared, bits[1]); check_version(p, d)
        require(p.state == 'READY', 'PREPARED_STATE', '이미 처리된 준비작업입니다.', 409)
        before = prepared_dict(p)
        if 'model_id' in d: get(db, Model, d['model_id']); p.model_id = d['model_id']
        if 'target_qty' in d: p.target_qty = qty(d['target_qty'], True)
        if 'position' in d: require(type(d['position']) is int, 'INVALID_POSITION', '순서를 확인하세요.'); p.position = d['position']
        if d.get('state') == 'CANCELLED': p.state = 'CANCELLED'
        p.row_version += 1; audit(db, who, 'PREPARED_UPDATE', p.id, before, prepared_dict(p)); return prepared_dict(p), 200
    if path in ['runs/start', 'runs/record-completed']:
        r = start(db, who, d, historical=path.endswith('record-completed'))
        if path.endswith('record-completed'):
            require(bool(d.get('reason')), 'REASON_REQUIRED', '늦은 기록 이유가 필요합니다.')
            result = save_quantity(db, who, r, {**d, 'expected_version': 1}, final=True, historical=True)
        else: result = run_dict(db, r)
        return result, 201
    if len(bits) == 3 and bits[0] == 'runs':
        r = get(db, Run, bits[1]); action = bits[2]
        if action in ['close', 'quantity-snapshots', 'corrections', 'close-unreported', 'close-and-start-next']:
            if action in ['corrections', 'close-unreported']: role(actor, 'ADMIN', 'SUPERVISOR')
            result = save_quantity(db, who, r, d, final=action in ['close', 'close-unreported', 'close-and-start-next'],
                                   correction=action == 'corrections', unreported=action == 'close-unreported')
            if action == 'close-and-start-next':
                p = get(db, Prepared, d.get('next_prepared_id'))
                require(p.station_id == r.station_id and p.state == 'READY', 'NEXT_CONFLICT', '다음 준비가 변경되었습니다.', 409)
                n = start(db, who, {'station_id': r.station_id, 'model_id': p.model_id, 'order_ref': p.order_ref, 'target_qty': dec(p.target_qty)})
                p.state = 'CONSUMED'; p.row_version += 1
                result = {'closed': result, 'started': run_dict(db, n)}
            return result, 200
        if action == 'exceptions':
            check_version(r, d); require(bool(d.get('message')), 'MESSAGE_REQUIRED', '예외 내용을 입력하세요.')
            s = Support(station_id=r.station_id, run_id=r.id, message=d['message']); db.add(s); db.flush()
            audit(db, who, 'RUN_EXCEPTION', r.id, None, {'message': s.message}); return {'id': s.id}, 201
    if path == 'support-requests':
        get(db, Station, d.get('station_id')); require(bool(d.get('message')), 'MESSAGE_REQUIRED', '요청 내용을 입력하세요.')
        s = Support(station_id=d['station_id'], message=d['message']); db.add(s); db.flush()
        audit(db, who, 'SUPPORT', s.id, None, d); return {'id': s.id}, 201
    if len(bits) == 2 and bits[0] == 'support-requests':
        role(actor, 'ADMIN', 'SUPERVISOR'); s = get(db, Support, bits[1]); s.state = 'RESOLVED'
        audit(db, who, 'SUPPORT_RESOLVE', s.id, None, {'state': s.state}); return {'id': s.id, 'state': s.state}, 200
    if path == 'wip-observations':
        role(actor, 'ADMIN', 'SUPERVISOR'); get(db, Station, d.get('station_id'))
        status = d.get('status'); require(status in ['UNKNOWN', 'ESTIMATED', 'CONFIRMED'], 'INVALID_WIP', '재공 확인상태를 선택하세요.')
        require(status == 'UNKNOWN' or bool(d.get('evidence')), 'EVIDENCE_REQUIRED', '확인·추정 근거가 필요합니다.')
        w = Wip(station_id=d['station_id'], status=status, quantity=None if status == 'UNKNOWN' else qty(d.get('quantity')), unit=d.get('unit'), evidence=d.get('evidence'))
        db.add(w); db.flush(); audit(db, who, 'WIP_OBSERVATION', w.id, None, d); return {'id': w.id, 'status': status}, 201
    if path == 'users':
        role(actor, 'ADMIN')
        require(d.get('role') in ['ADMIN', 'SUPERVISOR', 'OPERATOR', 'VIEWER'], 'INVALID_ROLE', '역할을 확인하세요.')
        require(isinstance(d.get('password'), str) and len(d['password']) >= 12 and bool(d.get('username')), 'PASSWORD_REQUIRED', '계정과 12자 이상 암호가 필요합니다.')
        u = User(username=d['username'], role=d['role'], password_hash=PASSWORDS.hash(d['password'])); db.add(u); db.flush()
        audit(db, who, 'USER_CREATE', u.id, None, {'username': u.username, 'role': u.role}); return {'id': u.id}, 201
    if path == 'sources':
        role(actor, 'ADMIN'); get(db, Station, d.get('station_id'))
        require(bool(d.get('stream_id')) and bool(d.get('name')), 'SOURCE_REQUIRED', 'source 이름과 stream이 필요합니다.')
        s = Source(station_id=d['station_id'], stream_id=d['stream_id'], name=d['name']); db.add(s); db.flush()
        audit(db, who, 'SOURCE_CREATE', s.id, None, source_dict(s)); return source_dict(s), 201
    if len(bits) == 3 and bits[0] == 'sources' and bits[2] == 'configure':
        role(actor, 'ADMIN'); s = get(db, Source, bits[1]); before = source_dict(s)
        require(d.get('state') in ['UNCONFIGURED', 'SHADOW', 'COMMISSIONED', 'SUSPENDED'], 'INVALID_STATE', '수집 상태를 확인하세요.')
        caps = d.get('capabilities', []); require(isinstance(caps, list) and set(caps) <= {'RAW_CAPTURE', 'RUN_ATTRIBUTION'}, 'INVALID_CAPABILITY', '지원 능력을 확인하세요.')
        contract = d.get('contract', {})
        require(isinstance(contract,dict),'INVALID_CONTRACT','source 계약은 객체 형식이어야 합니다.')
        require(d['state'] != 'COMMISSIONED' or bool(d.get('reason')), 'COMMISSION_EVIDENCE_REQUIRED', '현장 승인 근거가 필요합니다.')
        if 'RUN_ATTRIBUTION' in caps:
            require(contract.get('cursor_kind') == 'GENERATION_SEQUENCE' and contract.get('async_safe') is True and bool(contract.get('approval_ref')), 'BOUNDARY_REQUIRED', '검증된 원본 경계와 비동기 안전 근거가 필요합니다.')
        s.state, s.capabilities, s.contract = d['state'], caps, contract
        audit(db, who, 'SOURCE_CONFIGURE', s.id, before, source_dict(s), d.get('reason')); return source_dict(s), 200
    if len(bits) == 3 and bits[0] == 'sources' and bits[2] == 'device-key':
        role(actor, 'ADMIN'); s = get(db, Source, bits[1])
        require(isinstance(d.get('device_key'),str) and len(d['device_key']) >= 32, 'DEVICE_KEY_REQUIRED', '관리 도구에서 생성한 32자 이상 장치키가 필요합니다.')
        s.token_hash = digest(d['device_key'])
        audit(db, who, 'DEVICE_KEY_ROTATE', s.id, None, {'rotated': True}); return {'source_id': s.id, 'rotated': True}, 200
    if len(bits) == 3 and bits[0] == 'conflicts' and bits[2] == 'resolve':
        role(actor,'ADMIN','SUPERVISOR'); c=get(db,Conflict,bits[1]);require(bool(d.get('reason')),'REASON_REQUIRED','검토 이유가 필요합니다.')
        c.state='RESOLVED';audit(db,who,'CONFLICT_REVIEW',c.id,None,{'state':c.state},d['reason']);return {'id':c.id,'state':c.state},200
    if path == 'source-activations/request':
        role(actor, 'ADMIN', 'SUPERVISOR'); s = get(db, Source, d.get('source_id')); r = get(db, Run, d.get('run_id'))
        require(r.station_id == s.station_id, 'SOURCE_STATION_MISMATCH', '기록지점이 다릅니다.')
        require(r.state=='ACTIVE','RUN_NOT_ACTIVE','진행 중인 작업에만 원본 경계를 요청할 수 있습니다.',409)
        a = Activation(source_id=s.id, run_id=r.id); db.add(a); db.flush(); return {'id': a.id, 'state': a.state}, 201
    if len(bits) == 3 and bits[0] == 'source-activations' and bits[2] == 'ack':
        a = get(db, Activation, bits[1]); s = get(db, Source, a.source_id)
        require(actor.get('source_id') == s.id or actor['role'] == 'ADMIN', 'FORBIDDEN', '다른 source입니다.', 403)
        require(s.state == 'COMMISSIONED' and 'RUN_ATTRIBUTION' in s.capabilities and s.contract.get('async_safe') is True, 'BOUNDARY_UNVERIFIED', '자동귀속이 승인되지 않았습니다.')
        require(isinstance(d.get('file_generation'), str) and bool(d['file_generation']) and type(d.get('lower_sequence')) is int and d['lower_sequence'] >= 0 and bool(d.get('evidence')), 'BOUNDARY_REQUIRED', '파일세대·원본순번·검증근거가 필요합니다.')
        require(a.state == 'PREPARING', 'ACTIVATION_STATE', '활성화 상태가 변경되었습니다.', 409)
        require(get(db,Run,a.run_id).state=='ACTIVE','RUN_NOT_ACTIVE','마감된 작업에 귀속 경계를 열 수 없습니다.',409)
        require(db.scalar(select(Activation).where(Activation.source_id==s.id,Activation.state=='ACTIVE')) is None,
                'BOUNDARY_OVERLAP','이전 원본 경계를 먼저 종료하세요.',409)
        upper = d.get('upper_sequence'); require(upper is None or type(upper) is int and upper >= d['lower_sequence'], 'INVALID_BOUNDARY', '종료 경계를 확인하세요.')
        for prev in db.scalars(select(Activation).where(Activation.source_id == s.id, Activation.state.in_(['ACTIVE', 'CLOSED']))):
            if prev.file_generation == d['file_generation']:
                require(prev.upper_sequence is not None and prev.upper_sequence <= d['lower_sequence'], 'BOUNDARY_OVERLAP', '이전 원본 경계를 먼저 종료하세요.', 409)
        a.file_generation=d['file_generation']; a.lower_sequence=d['lower_sequence']; a.upper_sequence=upper
        a.evidence=d['evidence']; a.state='CLOSED' if upper is not None else 'ACTIVE'
        audit(db, who, 'ACTIVATION_ACK', a.id, None, d); return {'id': a.id, 'state': a.state}, 200
    if len(bits) == 3 and bits[0] == 'source-activations' and bits[2] == 'close':
        role(actor, 'ADMIN'); a = get(db, Activation, bits[1])
        require(a.state == 'ACTIVE' and type(d.get('upper_sequence')) is int and d['upper_sequence'] >= a.lower_sequence, 'INVALID_BOUNDARY', '활성 경계와 종료 순번을 확인하세요.')
        a.upper_sequence=d['upper_sequence']; a.state='CLOSED'; audit(db, who, 'ACTIVATION_CLOSE', a.id, None, d); return {'id': a.id}, 200
    if path == 'integration/raw-captures':
        s = get(db, Source, d.get('source_id'))
        require(actor.get('source_id') == s.id or actor['role'] == 'ADMIN', 'FORBIDDEN', '다른 source입니다.', 403)
        try: raw = base64.b64decode(d.get('content_base64', ''), validate=True)
        except (ValueError, TypeError): raise Rejected('INVALID_FILE', '원본 인코딩을 확인하세요.')
        require(0 < len(raw) <= 2_000_000, 'INVALID_FILE_SIZE', '원본 파일 크기는 1~2,000,000바이트입니다.')
        parse_status=d.get('parse_status','UNPARSED')
        require(parse_status in ['UNPARSED','PARSED','PARSER_REVIEW_REQUIRED'],'INVALID_PARSE_STATUS','파싱 상태를 확인하세요.')
        parser_error=d.get('parser_error')
        require(parser_error is None or isinstance(parser_error,str) and len(parser_error)<=2000,'INVALID_PARSER_ERROR','파서 오류 형식을 확인하세요.')
        sha = hashlib.sha256(raw).hexdigest()
        quarantine=durable_original(root,sha,raw)
        c = Capture(source_id=s.id, sha256=sha, storage_key=sha, size=len(raw),parse_status=parse_status,parser_error=parser_error); db.add(c); db.flush()
        if quarantine:audit(db,who,'RAW_CORRUPTION_REPAIR',c.id,None,{'sha256':sha,'quarantine':quarantine})
        audit(db, who, 'RAW_CAPTURE', c.id, None, {'sha256': sha, 'size': len(raw)})
        return {'id': c.id, 'sha256': sha}, 201
    if path == 'integration/events':
        errors = sorted(SCHEMA.iter_errors(d), key=lambda e: str(e.path))
        require(not errors, 'INVALID_EVENT_SCHEMA', '검사 이벤트 v2 형식이 맞지 않습니다.')
        s = get(db, Source, d['source_id'])
        require(actor.get('source_id') == s.id or actor['role'] == 'ADMIN', 'FORBIDDEN', '다른 source입니다.', 403)
        require(mode == 'DEMO' or d['evidence']['origin'] == 'ACTUAL', 'SYNTHETIC_REJECTED', '운영에는 합성자료를 넣을 수 없습니다.')
        require(s.station_id == d['station_id'] and s.stream_id == d['source_stream_id'], 'SOURCE_CONTEXT_MISMATCH', '등록 source와 지점·stream이 다릅니다.')
        h = digest(canonical(d)); existing = db.scalar(select(Inspection).where(Inspection.source_id == s.id, Inspection.stream_id == s.stream_id, Inspection.source_event_key == d['source_event_key']))
        if existing:
            require(existing.payload_hash == h, 'EVENT_CONTENT_CONFLICT', '같은 원본키의 다른 내용을 검토함에 보존합니다.', 409)
            return {'id': existing.id, 'status': 'RECEIVED', 'duplicate': True}, 202
        require(db.get(Inspection, d['event_id']) is None, 'EVENT_ID_CONFLICT', '이벤트ID가 다른 원본에 사용됐습니다.', 409)
        if d.get('raw_capture_id'):
            c = get(db, Capture, d['raw_capture_id']); require(c.source_id == s.id and (not d.get('raw_file_hash') or c.sha256 == d['raw_file_hash']), 'RAW_CONTEXT_MISMATCH', '원본 파일 소유·해시가 다릅니다.')
        e = Inspection(id=d['event_id'], source_id=s.id, stream_id=s.stream_id, source_event_key=d['source_event_key'], payload_hash=h, raw_payload=d)
        db.add(e); s.last_received_at=now(); db.flush()
        return {'id': e.id, 'status': 'RECEIVED', 'validated_attribution': 'UNRESOLVED'}, 202
    if len(bits) == 4 and bits[:2] == ['integration', 'events'] and bits[3] == 'attribution-review':
        role(actor, 'ADMIN', 'SUPERVISOR'); e=get(db, Inspection, bits[2]); r=get(db, Run, d.get('run_id')); s=get(db, Source, e.source_id)
        require(r.station_id == s.station_id and bool(d.get('reason')), 'REVIEW_EVIDENCE_REQUIRED', '같은 기록지점과 귀속 근거가 필요합니다.')
        before={'run_id':e.run_id,'level':e.validated_attribution}; e.run_id=r.id; e.validated_attribution='RUN'; e.processing_status='REVIEWED'; e.review_reason=d['reason']
        audit(db, who, 'ATTRIBUTION_REVIEW', e.id, before, {'run_id':r.id,'level':'RUN'}, d['reason']); return {'id':e.id,'run_id':r.id,'validated_attribution':'RUN'},200
    if path.startswith(('identified/', 'quality/', 'packing/', 'shipment-candidates/', 'subcontract/')):
        raise Rejected('FEATURE_NOT_IMPLEMENTED', '선택 추적·품질·출하 기능은 미구현입니다.', 403)
    raise Rejected('NOT_FOUND', 'API 경로가 없습니다.', 404)
