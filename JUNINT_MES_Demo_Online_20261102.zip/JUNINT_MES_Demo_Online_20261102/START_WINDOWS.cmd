@echo off
setlocal
cd /d "%~dp0"
docker info >nul 2>&1
if errorlevel 1 (
  echo Please install and start Docker Desktop, then run this file again.
  pause
  exit /b 1
)
echo Building the MES app. Internet access is required on first run.
docker build --platform linux/amd64 -t junint-mes:desktop-demo-20261102 .
if errorlevel 1 goto failed
docker pull postgres@sha256:10a5c69a83035ab5239f5620d708520e8b28f5aa1f2b20143e6024532edadfb5
if errorlevel 1 goto failed
docker tag postgres@sha256:10a5c69a83035ab5239f5620d708520e8b28f5aa1f2b20143e6024532edadfb5 junint-mes-postgres:desktop-demo-20261102
if errorlevel 1 goto failed
if not exist .env (
  docker run --rm --network none --entrypoint python junint-mes:desktop-demo-20261102 -c "import secrets; print('POSTGRES_PASSWORD='+secrets.token_urlsafe(32))" > .env
  if errorlevel 1 goto failed
)
findstr /r /c:"^POSTGRES_PASSWORD=." .env >nul
if errorlevel 1 goto failed
docker compose up -d --wait --pull never
if errorlevel 1 goto failed
if not exist access mkdir access
docker compose cp bootstrap:/app/data/private/demo-credentials.json access\login.json
if errorlevel 1 goto failed
echo.
echo MES DEMO is ready. Login details are in access\login.json.
echo Your test data stays on this PC. Claude API keys are not required.
start "" "http://127.0.0.1:18000"
start "" notepad.exe "%cd%\access\login.json"
exit /b 0
:failed
echo.
echo Setup did not finish. Keep this window open and share the error text, not .env or login.json.
pause
exit /b 1
