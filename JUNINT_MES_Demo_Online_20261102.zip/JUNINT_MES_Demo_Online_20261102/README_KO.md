# 내 PC에서 MES DEMO 열기

## Windows

1. Docker Desktop을 설치하고 실행합니다. Linux containers 모드를 사용합니다.
2. ZIP을 **모두 압축 해제**한 뒤 `START_WINDOWS.cmd`를 더블클릭합니다.
3. 처음에는 이미지 빌드·DB 생성 때문에 시간이 걸립니다. 완료되면 브라우저와 로그인 정보 메모장이 열립니다.
4. 메모장에 표시된 `username`과 `password` 값으로 로그인합니다.

ZIP 안에서 직접 실행하지 마세요. 첫 실행에서 인터넷으로 공식 실행 이미지와 고정 의존성을 받습니다. Python·Node·Claude API 키는 필요 없습니다.
Docker Desktop과 첫 실행 시 인터넷 연결이 필요합니다. Windows 스크립트의 실기 시험은 하지 않았고,
동일한 Compose·초기화·앱 흐름은 Linux Docker와 실제 브라우저에서 검증했습니다.

## Mac / Linux

터미널에서 압축 해제한 폴더로 이동해 다음을 실행합니다.

```sh
bash START_MAC_LINUX.sh
```

Mac에서는 브라우저와 TextEdit을 열며, Linux에서는 브라우저를 열 수 있으면 엽니다.
로그인 정보는 `access/login.json`에서 확인합니다. 이미지 아키텍처는 linux/amd64이므로
Apple Silicon 등 ARM PC는 Docker의 amd64 에뮬레이션이 필요하며 실기 검증하지 않았습니다.

## 먼저 해볼 것

- 합성 데모 기록지점을 선택합니다.
- 합성 데모 모델 A를 선택하고 시작을 기록합니다.
- 다음 준비에 모델 B를 넣어도 현재 작업은 A로 유지되는지 확인합니다.
- 완료수량 한 칸에 `10`을 넣고 Enter를 눌러 마감합니다.
- 일일보고에서 해당 기록지점의 마감 신고수량을 확인합니다.

사용자 PC의 18000 포트를 사용하며 다른 PC나 인터넷에는 공개하지 않습니다.
이는 이 채팅의 클라우드 주소가 아니라 **직접 실행한 PC의 앱**입니다.
회사 실데이터·API 키·기존 DB는 패키지에 들어 있지 않습니다.
로그인 암호와 DB 암호는 처음 실행하는 PC에서 무작위로 생성합니다.

## 종료와 보관

Windows는 `STOP_WINDOWS.cmd`, Mac/Linux는 `bash STOP_MAC_LINUX.sh`를 실행합니다.
Docker Desktop에서도 종료할 수 있습니다. 시험 데이터는 Docker volume에 보존됩니다.
다시 START를 실행하면 기존 기록을 이어서 봅니다.
`.env`와 `access/login.json`을 타인에게 보내지 마세요.

실제 공장 연결·설비 제어·ERP 연결·운영 배포는 포함하지 않습니다.
문제가 생기면 오류 문구만 알려주세요. 암호 파일을 보내지 않아도 진단할 수 있습니다.
