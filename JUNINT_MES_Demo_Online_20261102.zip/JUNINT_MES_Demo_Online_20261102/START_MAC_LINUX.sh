#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if ! docker info >/dev/null 2>&1; then
  echo 'Install/start Docker Desktop (or Docker Engine with Compose) first.' >&2
  exit 1
fi
docker build --platform linux/amd64 -t junint-mes:desktop-demo-20261102 .
docker pull postgres@sha256:10a5c69a83035ab5239f5620d708520e8b28f5aa1f2b20143e6024532edadfb5
docker tag postgres@sha256:10a5c69a83035ab5239f5620d708520e8b28f5aa1f2b20143e6024532edadfb5 junint-mes-postgres:desktop-demo-20261102
if [[ ! -f .env ]]; then
  umask 077
  docker run --rm --network none --entrypoint python junint-mes:desktop-demo-20261102 -c "import secrets; print('POSTGRES_PASSWORD='+secrets.token_urlsafe(32))" >.env
fi
test -s .env
docker compose up -d --wait --pull never
mkdir -p access
chmod 700 access
docker compose cp bootstrap:/app/data/private/demo-credentials.json access/login.json
chmod 600 access/login.json
echo 'MES DEMO is ready. Login details: access/login.json. No Claude key is required.'
if [[ $(uname -s) == Darwin ]] && command -v open >/dev/null; then
  open http://127.0.0.1:18000
  open -a TextEdit access/login.json
elif command -v xdg-open >/dev/null; then
  xdg-open http://127.0.0.1:18000 >/dev/null 2>&1 || true
fi
