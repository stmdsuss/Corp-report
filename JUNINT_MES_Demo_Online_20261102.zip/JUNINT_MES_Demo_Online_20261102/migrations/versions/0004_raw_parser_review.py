"""Retain parser-failure originals centrally without fabricating inspection events."""
from alembic import op
import sqlalchemy as sa

revision='0004_raw_parser_review'
down_revision='0003_quantity_guard'


def upgrade():
    op.add_column('raw_captures',sa.Column('parse_status',sa.String(),nullable=False,server_default='UNPARSED'))
    op.add_column('raw_captures',sa.Column('parser_error',sa.Text(),nullable=True))


def downgrade():
    raise RuntimeError('Restore a backup instead of discarding parser review metadata.')
