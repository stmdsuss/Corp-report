"""Initial RUN observation schema; no physical inventory or optional gates."""
from alembic import op
from pathlib import Path

revision = '0001_observation'
down_revision = None


def upgrade():
    schema=Path(__file__).resolve().parents[1]/'schema0001.sql'
    for statement in schema.read_text().split(';'):
        if statement.strip():op.execute(statement)
    op.execute("CREATE UNIQUE INDEX one_active_run_per_station ON production_runs (station_id) WHERE state = 'ACTIVE'")
    op.execute("ALTER TABLE production_runs ADD CONSTRAINT valid_run_kind CHECK (run_kind IN ('NORMAL','REWORK','REFERENCE'))")
    op.execute("ALTER TABLE production_runs ADD CONSTRAINT valid_run_state CHECK (state IN ('ACTIVE','CLOSED'))")
    op.execute("ALTER TABLE run_quantity_snapshots ADD CONSTRAINT valid_quantity CHECK ((report_status = 'REPORTED' AND quantity >= 0) OR (report_status = 'UNREPORTED' AND quantity IS NULL))")
    op.execute("ALTER TABLE run_quantity_snapshots ADD CONSTRAINT unique_run_snapshot UNIQUE (run_id, version)")


def downgrade():
    raise RuntimeError('Destructive rollback is intentionally unavailable; restore a verified backup.')
