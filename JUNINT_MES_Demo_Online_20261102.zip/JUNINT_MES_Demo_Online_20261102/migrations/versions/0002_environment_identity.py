"""Bind a database to its DEMO or PRODUCTION environment."""
from alembic import op
import sqlalchemy as sa

revision='0002_environment_identity'
down_revision='0001_observation'


def upgrade():
    # 0001 predates this table; fresh installs may see it from initial metadata.
    if not sa.inspect(op.get_bind()).has_table('database_identity'):
        op.create_table('database_identity',sa.Column('id',sa.String(),primary_key=True),sa.Column('mode',sa.String(),nullable=False))


def downgrade():
    raise RuntimeError('Restore a backup instead of removing the environment boundary.')
