"""Reject unknown/NaN values in reported snapshots at the DB boundary."""
from alembic import op

revision='0003_quantity_guard'
down_revision='0002_environment_identity'


def upgrade():
    op.execute('ALTER TABLE run_quantity_snapshots DROP CONSTRAINT valid_quantity')
    op.execute("""ALTER TABLE run_quantity_snapshots ADD CONSTRAINT valid_quantity CHECK (
      (report_status='REPORTED' AND quantity IS NOT NULL AND quantity >= 0
       AND quantity NOT IN ('NaN'::numeric,'Infinity'::numeric,'-Infinity'::numeric))
      OR (report_status='UNREPORTED' AND quantity IS NULL))""")


def downgrade():
    raise RuntimeError('Restore a backup rather than weakening quantity integrity.')
