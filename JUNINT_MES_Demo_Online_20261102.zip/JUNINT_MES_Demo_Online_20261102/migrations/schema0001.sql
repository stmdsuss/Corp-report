CREATE TABLE audit_events (
	id VARCHAR NOT NULL, 
	actor_id VARCHAR NOT NULL, 
	action VARCHAR NOT NULL, 
	entity_id VARCHAR, 
	before JSONB, 
	after JSONB NOT NULL, 
	reason TEXT, 
	recorded_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id)
);

CREATE TABLE commands (
	key VARCHAR NOT NULL, 
	actor_id VARCHAR NOT NULL, 
	digest VARCHAR NOT NULL, 
	response JSONB NOT NULL, 
	status INTEGER NOT NULL, 
	recorded_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (key)
);

CREATE TABLE models (
	id VARCHAR NOT NULL, 
	code VARCHAR NOT NULL, 
	name VARCHAR NOT NULL, 
	aliases JSONB NOT NULL, 
	specifications JSONB NOT NULL, 
	active BOOLEAN NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (code)
);

CREATE TABLE review_conflicts (
	id VARCHAR NOT NULL, 
	actor_id VARCHAR NOT NULL, 
	command_key VARCHAR NOT NULL, 
	request JSONB NOT NULL, 
	reason TEXT NOT NULL, 
	state VARCHAR NOT NULL, 
	recorded_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id)
);

CREATE TABLE stations (
	id VARCHAR NOT NULL, 
	name VARCHAR NOT NULL, 
	process VARCHAR NOT NULL, 
	final_reporting BOOLEAN NOT NULL, 
	active BOOLEAN NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (name)
);

CREATE TABLE users (
	id VARCHAR NOT NULL, 
	username VARCHAR NOT NULL, 
	password_hash TEXT NOT NULL, 
	role VARCHAR NOT NULL, 
	active BOOLEAN NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (username)
);

CREATE TABLE favorites (
	user_id VARCHAR NOT NULL, 
	model_id VARCHAR NOT NULL, 
	PRIMARY KEY (user_id, model_id), 
	FOREIGN KEY(user_id) REFERENCES users (id), 
	FOREIGN KEY(model_id) REFERENCES models (id)
);

CREATE TABLE login_sessions (
	token_hash VARCHAR NOT NULL, 
	user_id VARCHAR NOT NULL, 
	expires_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (token_hash), 
	FOREIGN KEY(user_id) REFERENCES users (id)
);

CREATE TABLE measurement_policies (
	id VARCHAR NOT NULL, 
	station_id VARCHAR NOT NULL, 
	version INTEGER NOT NULL, 
	unit VARCHAR, 
	boundary TEXT, 
	inclusion TEXT, 
	decimal_places INTEGER NOT NULL, 
	state VARCHAR NOT NULL, 
	recorded_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (station_id, version), 
	FOREIGN KEY(station_id) REFERENCES stations (id)
);

CREATE TABLE prepared_jobs (
	id VARCHAR NOT NULL, 
	station_id VARCHAR NOT NULL, 
	model_id VARCHAR NOT NULL, 
	state VARCHAR NOT NULL, 
	row_version INTEGER NOT NULL, 
	position INTEGER NOT NULL, 
	target_qty NUMERIC(24, 6), 
	order_ref VARCHAR, 
	PRIMARY KEY (id), 
	FOREIGN KEY(station_id) REFERENCES stations (id), 
	FOREIGN KEY(model_id) REFERENCES models (id)
);

CREATE TABLE sources (
	id VARCHAR NOT NULL, 
	station_id VARCHAR NOT NULL, 
	stream_id VARCHAR NOT NULL, 
	name VARCHAR NOT NULL, 
	state VARCHAR NOT NULL, 
	capabilities JSONB NOT NULL, 
	token_hash VARCHAR, 
	contract JSONB NOT NULL, 
	last_received_at TIMESTAMP WITH TIME ZONE, 
	PRIMARY KEY (id), 
	FOREIGN KEY(station_id) REFERENCES stations (id), 
	UNIQUE (token_hash)
);

CREATE TABLE wip_observations (
	id VARCHAR NOT NULL, 
	station_id VARCHAR NOT NULL, 
	status VARCHAR NOT NULL, 
	quantity NUMERIC(24, 6), 
	unit VARCHAR, 
	evidence TEXT, 
	recorded_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(station_id) REFERENCES stations (id)
);

CREATE TABLE production_runs (
	id VARCHAR NOT NULL, 
	station_id VARCHAR NOT NULL, 
	model_id VARCHAR NOT NULL, 
	policy_id VARCHAR, 
	row_version INTEGER NOT NULL, 
	state VARCHAR NOT NULL, 
	coverage_mode VARCHAR NOT NULL, 
	run_kind VARCHAR NOT NULL, 
	order_ref VARCHAR, 
	target_qty NUMERIC(24, 6), 
	model_snapshot JSONB NOT NULL, 
	started_recorded_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	close_recorded_at TIMESTAMP WITH TIME ZONE, 
	actor_id VARCHAR NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(station_id) REFERENCES stations (id), 
	FOREIGN KEY(model_id) REFERENCES models (id), 
	FOREIGN KEY(policy_id) REFERENCES measurement_policies (id), 
	FOREIGN KEY(actor_id) REFERENCES users (id)
);

CREATE INDEX ix_production_runs_close_recorded_at ON production_runs (close_recorded_at);

CREATE INDEX ix_production_runs_station_id ON production_runs (station_id);

CREATE TABLE raw_captures (
	id VARCHAR NOT NULL, 
	source_id VARCHAR NOT NULL, 
	sha256 VARCHAR NOT NULL, 
	storage_key VARCHAR NOT NULL, 
	size INTEGER NOT NULL, 
	received_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(source_id) REFERENCES sources (id)
);

CREATE TABLE integration_events (
	id VARCHAR NOT NULL, 
	source_id VARCHAR NOT NULL, 
	stream_id VARCHAR NOT NULL, 
	source_event_key VARCHAR NOT NULL, 
	payload_hash VARCHAR NOT NULL, 
	raw_payload JSONB NOT NULL, 
	run_id VARCHAR, 
	validated_attribution VARCHAR NOT NULL, 
	processing_status VARCHAR NOT NULL, 
	review_reason TEXT, 
	received_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (source_id, stream_id, source_event_key), 
	FOREIGN KEY(source_id) REFERENCES sources (id), 
	FOREIGN KEY(run_id) REFERENCES production_runs (id)
);

CREATE TABLE run_quantity_snapshots (
	id VARCHAR NOT NULL, 
	run_id VARCHAR NOT NULL, 
	quantity NUMERIC(24, 6), 
	delta NUMERIC(24, 6), 
	report_status VARCHAR NOT NULL, 
	is_final BOOLEAN NOT NULL, 
	version INTEGER NOT NULL, 
	exception_quantities JSONB NOT NULL, 
	correction_of VARCHAR, 
	reason TEXT, 
	recorded_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	actor_id VARCHAR NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(run_id) REFERENCES production_runs (id), 
	FOREIGN KEY(actor_id) REFERENCES users (id)
);

CREATE INDEX ix_run_quantity_snapshots_run_id ON run_quantity_snapshots (run_id);

CREATE TABLE run_time_records (
	id VARCHAR NOT NULL, 
	run_id VARCHAR NOT NULL, 
	event_kind VARCHAR NOT NULL, 
	occurred_at_claimed TIMESTAMP WITH TIME ZONE, 
	time_basis VARCHAR NOT NULL, 
	client_entered_at TIMESTAMP WITH TIME ZONE, 
	recorded_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	evidence TEXT, 
	PRIMARY KEY (id), 
	FOREIGN KEY(run_id) REFERENCES production_runs (id)
);

CREATE TABLE source_activations (
	id VARCHAR NOT NULL, 
	source_id VARCHAR NOT NULL, 
	run_id VARCHAR NOT NULL, 
	state VARCHAR NOT NULL, 
	file_generation VARCHAR, 
	lower_sequence INTEGER, 
	upper_sequence INTEGER, 
	evidence JSONB NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(source_id) REFERENCES sources (id), 
	FOREIGN KEY(run_id) REFERENCES production_runs (id)
);

CREATE TABLE support_requests (
	id VARCHAR NOT NULL, 
	station_id VARCHAR NOT NULL, 
	run_id VARCHAR, 
	message TEXT NOT NULL, 
	state VARCHAR NOT NULL, 
	recorded_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(station_id) REFERENCES stations (id), 
	FOREIGN KEY(run_id) REFERENCES production_runs (id)
);
